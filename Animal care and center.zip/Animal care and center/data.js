const firebaseConfig = {
    apiKey: "AIzaSyAdEpzbWPSIWIEY9ZjIbjKc5vgos5uC-k8",
    authDomain: "st-c4136.firebaseapp.com",
    databaseURL: "https://st-c4136-default-rtdb.firebaseio.com",
    projectId: "st-c4136",
    storageBucket: "st-c4136.appspot.com",
    messagingSenderId: "4437422395",
    appId: "1:4437422395:web:a69517577551a1c3b6871e",
    measurementId: "G-HXGB1CHF5L"
};


firebase.initializeApp(firebaseConfig);

//reference data base
const animalDB = firebase.database().ref("animal")