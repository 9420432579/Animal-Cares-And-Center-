<!-- <?php
$name = $_POST['name'];
$password = $_POST['password'];

//database connection
$conne = new mysqli('localhost','root','','login');
if($conne->connect_error){
    die('connection failed: ' . $conne->connect_error);

}else{
    $stmt = $conn->prepare("select * from regitrations where name = ?");
    $stmt->bind_param("s",$name );
    $stmt->execute();
   $stmt_result $stmt->get result();
   if($stmt_result->num_rows > 0){
    $data =$stmt_result
    $stmt->close();
    $stmt->close();
} -->